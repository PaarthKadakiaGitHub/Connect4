public class AIPlayer extends Player {
    protected char symbol;
	protected Board board;
	protected String name;
    int i;
    int k;
    Character[][] f;

    public AIPlayer(char symbol, Board board, String name) {
		super(symbol, board, name);
        this.name = name;
        this.board = board;
        this.symbol = symbol;
	}
    
	public Character[][] getArray2(){return f;}


    public void makeMove(Board board){
        this.board = board;

		int randomInt = (int)(6.0 * Math.random());
		randomInt += 1;

        System.out.print(name + ", please input your move (1-7): " + randomInt+ "\n");
        int c = 2*randomInt-1;


        f = board.getArray();
        for (int i = board.getRows() - 1;i>=0;i--) {
            if (f[i][c] == '_' ) {
                f[i][c] = symbol;
                break;}
            if (f[i][c] == ' ' ) {
                f[i][c] = symbol;
                break;
            }

        }
    }
}
    

