import java.lang.reflect.Array;
import java.rmi.registry.Registry;
import java.util.ArrayList;


public class Board {

	private final int NUM_OF_COLUMNS = 7;
	private final int NUM_OF_ROW = 6;
	public Character[][] a = new Character[NUM_OF_ROW][NUM_OF_COLUMNS*2 + 1];
	public Character[][] reset;
	public String stringBoard = "";
	public Player player;
	/* 
	 * The board object must contain the board state in some manner.
	 * You must decide how you will do this.
	 * 
	 * You may add addition private/public methods to this class is you wish.
	 * However, you should use best OO practices. That is, you should not expose
	 * how the board is being implemented to other classes. Specifically, the
	 * Player classes.
	 * 
	 * You may add private and public methods if you wish. In fact, to achieve
	 * what the assignment is asking, you'll have to
	 * 
	 */

	public void update(Player player){
		this.player = player;
		
		a = player.getArray2();
		
	}
	public int getColumns(){ return (NUM_OF_COLUMNS);}
	public int getRows(){ return NUM_OF_ROW;}
	public Character[][] getArray(){ return a;}

	public void Board() {
		for(int i = 0; i<NUM_OF_ROW; i++){
			for(int j = 0; j<(NUM_OF_COLUMNS*2 + 1); j++){
				if(j%2 == 0){
					a[i][j] = '|';

				}

				if(j%2 == 1){
					a[i][j] = ' ';
				}
				if((j%2 == 1) && i == (NUM_OF_ROW - 1)){
					a[i][j] = '_';
				}
				
	
			}
		}
	reset = a;


	}

	
	
	public String printBoard() {
		stringBoard = "";
		for(int i = 0; i<NUM_OF_ROW; i++){
			for(int j = 0; j<(NUM_OF_COLUMNS*2 + 1); j++){
				stringBoard += a[i][j];
			}
		stringBoard += '\n';	
		}
		System.out.println(stringBoard);


		return stringBoard;

		//TODO
	}
	
	public boolean containsWin() {

		for (int i =0;i<NUM_OF_ROW;i++) {


			for (int j=0;j<NUM_OF_COLUMNS;j+=2) {
				if((a[i][j+1] != ' ') && (a[i][j+1] != '_')  && (a[i][j+1] == a[i][j+3]) && (a[i][j+3] == a[i][j+5]) && (a[i][j+5] == a[i][j+7]))
	   
					return true; 
			}

		}
	   
		for (int i=1;i<(NUM_OF_COLUMNS*2 + 1);i+=2) {
			for (int j =0;j<NUM_OF_ROW/2;j++) {
					if((a[j][i] != ' ')  && (a[j][i] != '_') && (a[j][i] == a[j+1][i]) && (a[j+1][i] == a[j+2][i]) && (a[j+2][i] == a[j+3][i]))
						return true; 
			} 
		  }
	   
		for (int i=0;i<3;i++) {
	   
			for (int j=1;j<9;j+=2) {
					if((a[i][j] != ' ') && (a[i][j] != '_') && (a[i][j] == a[i+1][j+2]) && (a[i+1][j+2] == a[i+2][j+4]) && (a[i+2][j+4] == a[i+3][j+6]))
						return true; 
			} 
		  }
	   
		for (int i=0;i<3;i++) {
			for (int j=NUM_OF_COLUMNS;j<(NUM_OF_COLUMNS*2+1);j+=2) {
					if((a[i][j] != ' ')  && (a[i][j] != '_') && (a[i][j] == a[i+1][j-2]) && (a[i+1][j-2] == a[i+2][j-4]) && (a[i+2][j-4] == a[i+3][j-6]))
						return true; 
			} 
		  }
		return false;
		//TODO
	}
	
	public boolean isTie() {
		for(int i = 0; i<NUM_OF_ROW; i++){
			for(int j = 0; j<(NUM_OF_COLUMNS*2 + 1); j++){
				if(a[i][j] == ' '){return false;}
			}
		}
		return true;

	}
	
	public void reset() {
		Board();
		
	}
	public static void main(String[] args) {
		Board board = new Board();
		board.Board();
		board.printBoard();


		
	}
}
