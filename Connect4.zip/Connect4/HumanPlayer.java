import java.util.Scanner;
public class HumanPlayer extends Player {
    public char symbol;
	public Board board;
	public String name;
    int i;
    int k;
    Character[][] f;
    

	public Character[][] getArray2(){return f;}

	public HumanPlayer(char symbol, Board board, String name) {
		super(symbol, board, name);
        this.name = name;
        this.board = board;
        this.symbol = symbol;
	}


    public boolean ColumnoutofBounds(Board board, int y){
        this.board = board;
        i = board.getColumns()*2 - 1;


        if((y-1) > i){
            return true;
        
        } 
    return false;


    }

    public void makeMove(Board board){
        this.board = board;
        

        System.out.print(name + ", please input your move (1-7): ");
        Scanner scan = new Scanner (System.in);
        int c = 2*scan.nextInt()-1;

        if(ColumnoutofBounds(board, c)){
            System.out.println("OUTTA BOUNDS");
            makeMove(board);

        }


        f = board.getArray();
        for (int i = board.getRows() - 1;i>=0;i--) {
            
            if (f[i][c] == '_' ) {
                f[i][c] = symbol;
                break;}
            if (f[i][c] == ' ' ) {
                f[i][c] = symbol;
                break;
          }
            
                
        
        

        }
    }
}
    

